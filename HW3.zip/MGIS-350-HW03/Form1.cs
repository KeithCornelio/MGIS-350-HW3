﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MGIS_350_HW03
{
    public partial class Form1 : Form
    {

        double subtotal = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            double input = Convert.ToDouble(txtInput.Text);
            if (subtotal > 0)
                lblPositive.Text = subtotal.ToString();


        }
            
            



        }
    }
}
